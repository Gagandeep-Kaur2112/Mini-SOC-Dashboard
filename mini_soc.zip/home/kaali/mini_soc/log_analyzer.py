import re
from collections import defaultdict

log_file = "sample.log"

failed_logins = defaultdict(int)

# Read log file
with open(log_file, "r") as file:
    for line in file:

        if "Failed password" in line:

            ip = re.findall(r'[0-9]+(?:\.[0-9]+){3}', line)

            if ip:
                failed_logins[ip[0]] += 1

# Detection Logic
THRESHOLD = 5
alerts = []

for ip, count in failed_logins.items():

    if count > THRESHOLD:
        alerts.append((ip, count))

# Generate Report
with open("report.txt", "w") as report:

    report.write("Failed Login Attempts:\n\n")

    for ip, count in failed_logins.items():
        report.write(f"{ip} -> {count}\n\n")

    report.write("\nALERTS:\n\n")

    for ip, count in alerts:
        report.write(f"{ip} suspicious with {count} attempts\n\n")

print("✅ Analysis Done. Check report.txt")
