import time
import re
import json
from collections import defaultdict

LOG_FILE = "/var/log/auth.log"
ALERT_FILE = "alerts/alerts.json"

failed_attempts = defaultdict(int)

print("[*] SOC Monitor Started...")

def save_alert(alert):

    try:
        with open(ALERT_FILE, "r") as f:
            alerts = json.load(f)

    except:
        alerts = []

    alerts.append(alert)

    with open(ALERT_FILE, "w") as f:
        json.dump(alerts, f, indent=4)

with open(LOG_FILE, "r") as file:

    file.seek(0,2)

    while True:

        line = file.readline()

        if not line:
            time.sleep(0.5)
            continue

        print("[LOG]", line.strip())

        if "Failed password" in line:

            ip_match = re.search(r'from\s+([0-9a-fA-F\:\.]+)', line)

            if ip_match:

                ip = ip_match.group(1)

                failed_attempts[ip] += 1

                print(f"[!] Failed Login From {ip}")

                print(f"[COUNT] {ip} = {failed_attempts[ip]}")

                if failed_attempts[ip] >= 5:

                    alert = {

                        "ip": ip,
                        "attempts": failed_attempts[ip],
                        "severity": "HIGH",
                        "type": "Brute Force Attack"

                    }

                    print("[ALERT] Brute Force Detected!")

                    save_alert(alert)
