from flask import Flask, render_template
import json

app = Flask(__name__)

@app.route("/")
def dashboard():

    try:
        with open("alerts/alerts.json", "r") as f:
            alerts = json.load(f)
    except:
        alerts = []

    total_alerts = len(alerts)

    high_alerts = 0

    ip_count = {}

    for alert in alerts:

        if alert["severity"] == "HIGH":
            high_alerts += 1

        ip = alert["ip"]

        if ip in ip_count:
            ip_count[ip] += 1
        else:
            ip_count[ip] = 1

    labels = list(ip_count.keys())
    values = list(ip_count.values())

    return render_template(
        "dashboard.html",
        alerts=alerts,
        total_alerts=total_alerts,
        high_alerts=high_alerts,
        labels=labels,
        values=values
    )

if __name__ == "__main__":
    app.run(debug=True)

